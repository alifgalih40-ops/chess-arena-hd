CHESS ARENA HD — GITHUB PAGES

Struktur:
- index.html  <- upload file ini ke root repository GitHub.

CARA PUBLISH:
1. Buka GitHub dan buat repository baru, misalnya: chess-arena-hd
2. Upload index.html ke repository tersebut.
3. Buka Settings -> Pages.
4. Pada Build and deployment pilih:
   Source: Deploy from a branch
   Branch: main
   Folder: / (root)
5. Klik Save.
6. Tunggu beberapa saat. Link biasanya berbentuk:
   https://USERNAME.github.io/chess-arena-hd/

CATATAN:
- Jangan masukkan index.html ke folder tambahan.
- Nama file harus tepat: index.html
- Game ini dibuat sebagai satu file HTML sehingga tidak memerlukan server/database.
